export const environment = 
{
  production: false,

  firebase :
  {
  }
};
