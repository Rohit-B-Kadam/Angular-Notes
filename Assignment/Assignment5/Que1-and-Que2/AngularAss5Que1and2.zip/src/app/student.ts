export class Student {

    constructor(
        public StudName:string,
        public StudMobile:string,
        public StudEmail:string,
        public StudCollege:string,
        public StudGender:string,
        public StudBatch:string,
        public StudAddress:string,
    ){ }
}
