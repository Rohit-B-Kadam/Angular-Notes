export class Student {
    
    constructor(
        public name:String,
        public college:String,
        public password:String
    ){ }
}
